module DTea {
	opens main;
	opens pages;
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.media;
	requires javafx.base;
}